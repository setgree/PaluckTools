## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----simulate_data------------------------------------------------------------
library(BLPlabtools)
library(dplyr)

set.seed(123)  # For reproducibility

# Simulate experimental data
n_schools <- 20
n_per_school <- 100
n_total <- n_schools * n_per_school

experiment_data <- data.frame(
  student_id = 1:n_total,
  school_id = rep(1:n_schools, each = n_per_school),
  # Treatment assignment (randomized within schools)
  treatment = rep(c(rep(0, n_per_school/2), rep(1, n_per_school/2)), n_schools),
  # Baseline covariates
  baseline_score = rnorm(n_total, mean = 70, sd = 15),
  gender = sample(c("female", "male"), n_total, replace = TRUE),
  # Outcomes (treatment effect = +5 points on average)
  test_score = 70 + 5*rep(c(rep(0, n_per_school/2), rep(1, n_per_school/2)), n_schools) +
               rnorm(n_total, sd = 12),
  attendance = 0.85 + 0.03*rep(c(rep(0, n_per_school/2), rep(1, n_per_school/2)), n_schools) +
               rnorm(n_total, sd = 0.1),
  attitudes = 3.5 + 0.3*rep(c(rep(0, n_per_school/2), rep(1, n_per_school/2)), n_schools) +
              rnorm(n_total, sd = 0.8)
) |>
  mutate(
    treatment = factor(treatment, levels = c(0, 1), labels = c("Control", "Treatment")),
    gender = factor(gender)
  )

# Preview the data structure
head(experiment_data)

## ----basic_tidy_lm------------------------------------------------------------
# Simple treatment effect
results <- tidy_lm(
  data = experiment_data,
  dv = "test_score",
  terms = "treatment",
  treatment = "treatment"
)

# View treatment coefficient
results |> select(dv, treatmentTreatment_coef, treatmentTreatment_p)

## ----multiple_dvs-------------------------------------------------------------
# Test treatment on test scores, attendance, and attitudes
multi_outcome <- tidy_lm(
  data = experiment_data,
  dv = c("test_score", "attendance", "attitudes"),
  terms = "treatment",
  treatment = "treatment"
)

# View treatment effects across all outcomes
multi_outcome |> select(dv, treatmentTreatment_coef, treatmentTreatment_p)

## ----regression_styles--------------------------------------------------------
# "bivariate": treatment only
bivariate <- tidy_lm(
  data = experiment_data,
  dv = "test_score",
  terms = "treatment",
  style = "bivariate"
)

# "incremental": progressively add controls
incremental <- tidy_lm(
  data = experiment_data,
  dv = "test_score",
  terms = c("treatment", "baseline_score", "gender"),
  treatment = "treatment",
  style = "incremental"
)

# "default": all terms together
full_model <- tidy_lm(
  data = experiment_data,
  dv = "test_score",
  terms = c("treatment", "baseline_score", "gender"),
  treatment = "treatment",
  style = "default"
)

cat("Bivariate:", nrow(bivariate), "model\n")
cat("Incremental:", nrow(incremental), "models (adds controls one at a time)\n")
cat("Default:", nrow(full_model), "model (all controls together)\n")

## ----typical_workflow---------------------------------------------------------
# Analyze all outcomes with progressive controls
full_analysis <- tidy_lm(
  data = experiment_data,
  dv = c("test_score", "attendance", "attitudes"),
  terms = c("treatment", "baseline_score", "gender"),
  treatment = "treatment",
  style = "incremental"
)

# Extract treatment effects across all specifications
full_analysis |>
  select(model_number, dv, treatmentTreatment_coef,
         treatmentTreatment_se, treatmentTreatment_p) |>
  mutate(significant = treatmentTreatment_p < 0.05)

## ----robust_se----------------------------------------------------------------
# Basic regression (ignores clustering)
model <- lm(test_score ~ treatment + baseline_score, data = experiment_data)

# Get cluster-robust SEs (clustering by school)
robust_results <- robust_se(model, cluster = experiment_data$school_id)

# robust_results is a list with:
# [[1]]: variance-covariance matrix
# [[2]]: coefficient test with robust SEs

robust_results[[2]]

## ----tidy_lm_clusters---------------------------------------------------------
# Run multiple specifications with clustering
clustered_models <- tidy_lm(
  data = experiment_data,
  dv = c("test_score", "attendance"),
  terms = c("treatment", "baseline_score", "gender"),
  treatment = "treatment",
  clusters = "school_id",
  style = "incremental"
)

# Extract treatment effects (now with cluster-robust SEs)
clustered_models |>
  select(dv, model_number, treatmentTreatment_coef, treatmentTreatment_se, treatmentTreatment_p)

## ----star_ready_demo, eval=FALSE----------------------------------------------
# # First, run your models
# models <- tidy_lm(
#   data = experiment_data,
#   dv = "test_score",
#   terms = c("treatment", "baseline_score"),
#   style = "incremental"
# )
# 
# # Prepare for stargazer
# ready_for_table <- star_ready(models, data = experiment_data)
# 
# # Now use with stargazer (not run here to avoid LaTeX output)
# # library(stargazer)
# # stargazer(ready_for_table, type = "latex")

## ----table_utilities----------------------------------------------------------
# Format numbers consistently to 2 decimal places
values <- c(0.1543, 2.567, 10.2)
two_digits(values)

# Add parentheses (useful for standard errors in tables)
add_parentheses(two_digits(values))

# Add brackets [useful for confidence intervals]
add_brackets(two_digits(values))

## ----print_table, eval=FALSE--------------------------------------------------
# # Display LaTeX tables cleanly in R console
# library(knitr)
# my_table <- capture.output(kable(head(experiment_data), format = "latex"))
# print_table(my_table)  # Cleaner than cat()

## ----stargazer_pvalues, eval=FALSE--------------------------------------------
# # Capture stargazer output
# model <- lm(test_score ~ treatment, data = experiment_data)
# table_output <- capture.output(
#   stargazer(model, report = "csp", type = "latex")
# )
# 
# # Change p-value format from "p = 0.05" to [0.05]
# table_with_brackets <- stargazer_pvalues(table_output, "brackets")
# print_table(table_with_brackets)

## ----complete_workflow, eval=FALSE--------------------------------------------
# # 1. Run your regressions
# models <- tidy_lm(
#   data = experiment_data,
#   dv = c("test_score", "attendance"),
#   terms = c("treatment", "baseline_score", "gender"),
#   treatment = "treatment",
#   style = "incremental",
#   clusters = school_id
# )
# 
# # 2. Prepare for stargazer
# table_ready <- star_ready(models, data = experiment_data)
# 
# # 3. Create table
# library(stargazer)
# raw_table <- capture.output(
#   stargazer(
#     table_ready,
#     type = "latex",
#     title = "Effect of growth mindset intervention on student outcomes",
#     dep.var.labels = c("Test Score", "Attendance"),
#     notes = "Placeholder note text"
#   )
# )
# 
# # 4. Format the table
# formatted_table <- raw_table |>
#   add_endnote(
#     note = "Standard errors clustered by school. All models control for baseline scores and gender.",
#     size_in_inches = 6,
#     rm.stargazer.stars = TRUE
#   ) |>
#   table_label(caption = "main_results")
# 
# # 5. Print for LaTeX document
# print_table(formatted_table)

