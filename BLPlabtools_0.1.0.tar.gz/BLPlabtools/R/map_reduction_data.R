#' Meat and Animal Product Reduction Meta-Analysis Data
#'
#' A dataset from a meta-analysis examining interventions designed to reduce
#' consumption of meat and animal products. This dataset is included primarily
#' to demonstrate the `make_bib()` function, as it contains DOI/URL information
#' for bibliographic reference generation.
#'
#' @format A data frame with 112 rows and 40 variables:
#' \describe{
#'   \item{author}{First author's last name}
#'   \item{year}{Publication year}
#'   \item{title}{Study title}
#'   \item{doi}{DOI or URL for the study}
#'   \item{venue}{Publication venue (journal, dissertation, etc.)}
#'   \item{source}{How the study was identified}
#'   \item{intervention_condition}{Name of the intervention condition}
#'   \item{brief_description}{Brief description of the intervention}
#'   \item{study_num_within_paper}{Study number if paper contains multiple studies}
#'   \item{outcome}{Outcome measure description}
#'   \item{n_t_post}{Treatment group sample size at post-test}
#'   \item{n_c_post}{Control group sample size at post-test}
#'   \item{n_t_total_pop}{Treatment group total population}
#'   \item{n_c_total_pop}{Control group total population}
#'   \item{eff_type}{Effect size type}
#'   \item{u_s_d}{Unstandardized difference}
#'   \item{ctrl_sd}{Control group standard deviation}
#'   \item{neg_null_pos}{Direction of effect (-1, 0, or 1)}
#'   \item{delay}{Delay between intervention and outcome measurement (days)}
#'   \item{theory}{Primary theoretical approach}
#'   \item{secondary_theory}{Secondary theoretical approach, if applicable}
#'   \item{self_report}{Whether outcome is self-reported (Y/N)}
#'   \item{outcome_category}{Category of outcome measure}
#'   \item{cafeteria_or_restaurant__or_store_based}{Setting-based intervention (Y/N)}
#'   \item{leaflet}{Leaflet used in intervention (Y/N)}
#'   \item{video}{Video used in intervention (Y/N)}
#'   \item{delivery_method}{Method of intervention delivery}
#'   \item{internet}{Internet-based intervention (Y/N)}
#'   \item{cluster_assigned}{Whether assignment was at cluster level (Y/N)}
#'   \item{multi_component}{Multi-component intervention (Y/N)}
#'   \item{delay_post_endline}{Delay measured post-endline (days)}
#'   \item{public_pre_analysis_plan}{Public pre-analysis plan exists (Y/N)}
#'   \item{open_data}{Data publicly available (Y/N/URL)}
#'   \item{emotional_activation}{Emotional activation component (Y/N)}
#'   \item{advocacy_org}{Advocacy organization involved (Y/N)}
#'   \item{country}{Country where study was conducted}
#'   \item{population}{Population description}
#'   \item{age_info_if_given}{Age information if provided}
#'   \item{inclusion_exclusion}{Inclusion/exclusion notes}
#'   \item{notes}{Additional notes}
#' }
#'
#' @source Green, S., Paluck, E. L., Hennessy, M., & Goldberg, M. H. (2025).
#'   Meaningfully reducing consumption of meat and animal products is an unsolved
#'   problem: A meta-analysis. \emph{Appetite}, 208, 108233.
#'   \doi{10.1016/j.appet.2025.108233}
#'
#'   Original data repository: \url{https://github.com/hsflabstanford/vegan-meta}
#'
#' @examples
#' data(map_reduction_data)
#' head(map_reduction_data)
#'
#' # Show studies with DOIs (for bibliography generation)
#' library(dplyr)
#' map_reduction_data |>
#'   filter(grepl("^10\\.", doi)) |>
#'   select(author, year, title, doi) |>
#'   head()
"map_reduction_data"
